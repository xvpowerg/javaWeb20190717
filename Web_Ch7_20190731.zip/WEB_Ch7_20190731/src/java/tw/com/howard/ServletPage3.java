/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Optional;
/**
 *
 * @author howard
 */
@WebServlet(name = "ServletPage3", urlPatterns = {"/ServletPage3"})
public class ServletPage3 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
             HttpSession session = request.getSession();
          Optional<String[]> products = Optional.ofNullable((String[])session.getAttribute("products"));
           Optional<String> userName = Optional.ofNullable(request.getParameter("user_name"));
            Optional<String> userAddress = Optional.ofNullable(request.getParameter("user_address"));
            //System.out.println(products +" ");
            if (!products.isPresent()){
                //轉換網址不會變化 把工作轉交給另一個Servlet
                request.getRequestDispatcher("/ServletPage1").forward(request, response);
            }else if( !(userName.isPresent() && userAddress.isPresent())   ){
                //網址會變化
                response.sendRedirect("ServletPage2");
            }
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletPage1</title>");          
         
            out.println("</head>");
            out.println("<body>");
            out.println("<p>"+Tools.formatEmptyString(userName.orElse("使者名稱為填寫"), "未填寫姓名")+"</p>");     
            out.println("<p>"+Tools.formatEmptyString(userAddress.orElse("使者地址為填寫"), "未填地址")+"</p>");
            products.ifPresent((str)->{
                    for (int i =0;i < str.length;i++){
                         out.println("<p>"+str[i]+"</p>");  
                   }            
            });
          
            out.println("<h1>Servlet ServletPage1 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
