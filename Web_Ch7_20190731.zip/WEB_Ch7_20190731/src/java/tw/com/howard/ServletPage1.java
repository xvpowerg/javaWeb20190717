/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author howard
 */
@WebServlet(name = "ServletPage1", urlPatterns = {"/ServletPage1"})
public class ServletPage1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
          HttpSession session = request.getSession();
          session.setAttribute("name", "Ken");        
          System.out.println(session);
          

          
          
          
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletPage1</title>");            
            out.println("</head>");
            out.println("<body>");
           out.println("<form action=\"ServletPage2\" method=\"POST\">") ;
           for (int i =1;i<=30;i++){
            out.println( String.format("電視%d<input type=\"checkbox\"  "
                    + "name=\"product\" value=\"%d\" /><br/>", i,i)) ;    
           }
            out.println("<input type=\"submit\" value=\"下一步\"> ") ;
           out.println("</form> ") ;
                        //    
        
                    
    //           
             //
            
            
            
           //session 能存活的時間 以秒作為單位
            out.println("<h1>Session MaxInactiveInterval at " + 
                    session.getMaxInactiveInterval() / 60+ "分鐘</h1>");
             out.println("<h1>CreationTime " + 
                    session.getCreationTime()+ "</h1>");
             out.println("<h1>isNew " + 
                    session.isNew()+ "</h1>");   
             out.println("<h1>session getId " + 
                    session.getId()+ "</h1>");     
            
            out.println("</body>");
            out.println("</html>");
            
            //直接另Session失效
            //session.invalidate();
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
