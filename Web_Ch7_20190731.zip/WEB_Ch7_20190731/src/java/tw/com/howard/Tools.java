/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard;

/**
 *
 * @author howard
 */
public class Tools {
    public static String formatEmptyString(String data,String msg){
          data = data.trim();          
          if (data.isEmpty()){
              return msg;
          }
          return data;
   }
}
