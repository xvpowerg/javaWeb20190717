/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.howard.test.ajax;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.howard.test.ajax.javabean.ConnectionDB;
import com.howard.test.ajax.javabean.User;
import java.io.IOException;
import java.sql.Connection;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;
import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author howard
 */
@Path("user")
public class UserService {
    private static ArrayList<User>  userList = new ArrayList<>(); 
    
    
    static{
        for(int i = 1; i <= 5;i++){
            User user = new User(i,"User"+i,10+i);
            userList.add(user);
        }
    }
    @Context
    private UriInfo context;
  
    
    
      @Inject
     Connection conn;
    public UserService() {
        
    }
    @GET
    @Path("/{userId}")    
    //@Path("/{userId}")  以下網址的123為userId
    //http://localhost:8080/TestAJAX1/testajax/user/123
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson(@PathParam("userId") String userId) {
            ObjectMapper objectMapper = new ObjectMapper();
            //int id, String name, int age
           // User user = new User(1,"Ken",20);
           int id = Integer.parseInt(userId);
          Optional<User>  ou= userList.stream().filter((v)->v.getId() == id).findFirst();
           
            String json = null;
            try{              
                System.out.println(userId);
                if (ou.isPresent()){
                    json = objectMapper.writeValueAsString(ou.get());
                }else{
                    json = objectMapper.writeValueAsString(new User(0,"查無此人",0));
                }
                 
            }catch(Exception ex){
                System.out.println(ex);
            }            
          return json;  
    }
    
    @POST
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
    //@Consumes 讀取的內容為JSON 表示userJson為JSON
    public String createUser(String userJson){
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            //JSON 轉物件
           User user = objectMapper.readValue(userJson,User.class);        
           System.out.println(user+"");   
           System.out.println(userJson+""); 
           userList.add(user);
        }catch(IOException ex){
            System.out.println(ex);
             return "{statu:-100}";
        }
        
        return "{\"statu\":100}";
        
    } 
}
