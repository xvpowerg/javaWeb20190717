/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.howard.test.ajax.javabean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;

public class ConnectionDB {
    @Produces
    private  Connection getDBConnection() throws SQLException{
        String url = "jdbc:derby://127.0.0.1:1527/MyUser";
        String user = "qwer";
        String password = "qwer";
        Connection connection = DriverManager.getConnection(url, user, password);        
        return connection;
    }
    private void closeConnection(@Disposes Connection conn)throws SQLException{
        conn.close();
    }
}
