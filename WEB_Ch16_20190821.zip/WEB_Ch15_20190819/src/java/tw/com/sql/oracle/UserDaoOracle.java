/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.sql.oracle;

import java.sql.Connection;
import javax.inject.Inject;
import tw.com.sql.derby.*;
import tw.com.bean.User;
import tw.com.dao.UserDao;

/**
 *
 * @author howard
 */
public class UserDaoOracle  implements UserDao{

    @Override
    public boolean createUser(String acount, String password) {
            return false;
    }

    @Override
    public User readUser(String acount, String password) {
        return null;
    }

    @Override
    public boolean isOnlyAcount(String acount) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
