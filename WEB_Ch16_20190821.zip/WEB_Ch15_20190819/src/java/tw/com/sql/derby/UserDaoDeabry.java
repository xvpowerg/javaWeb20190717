/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.sql.derby;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import tw.com.bean.User;
import tw.com.dao.UserDao;

/**
 *
 * @author howard
 */
public class UserDaoDeabry  implements UserDao{
    private Connection conn;
    
    public UserDaoDeabry(){
        
    }
    public UserDaoDeabry(Connection conn){
        this.conn = conn;
    }
    
    @Override
    public boolean createUser(String acount, String password)throws SQLException {
        java.util.Random random = new java.util.Random();
        int id = random.nextInt(Integer.MAX_VALUE);
        String sqlStyle="INSERT INTO ACOUNT(ID,ACOUNT,PASSWORD) VALUES(%d,'%s','%s')";
        String sql = String.format(sqlStyle, id,acount,password);
        System.out.println("sql:"+sql);
         Statement smt =  conn.createStatement();
         int count = smt.executeUpdate(sql);        
       return count > 0;
    }

    @Override
    public User readUser(String acount, String password)throws SQLException {
        return null;
    }

    @Override
    public boolean isOnlyAcount(String acount)throws SQLException {
      Statement smt =  conn.createStatement();
      boolean isOnly = false;
        ResultSet result = 
                smt.executeQuery("SELECT ID FROM ACOUNT WHERE ACOUNT='"+acount+"'");
        isOnly = !result.next();
      return isOnly;
    }
    
}
