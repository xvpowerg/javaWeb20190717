/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.data;

import java.sql.Connection;
import tw.com.dao.UserDao;
import tw.com.sql.derby.UserDaoDeabry;
import tw.com.sql.oracle.UserDaoOracle;

/**
 *
 * @author howard
 */
public class DaoFactory {
    static int type = 1;
    public static UserDao newUserDao(Connection conn){
        switch(type){
            case 1:
           return new UserDaoDeabry(conn);
            case 2:
           return new UserDaoOracle();
        }
        return null;
    }
}
