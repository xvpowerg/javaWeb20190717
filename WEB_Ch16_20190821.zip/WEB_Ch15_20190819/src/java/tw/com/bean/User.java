/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.bean;

/**
 *
 * @author howard
 */
public class User {
    private int id;
    private String acount;
    private String password;

    public User() {
    }

    public User(int id, String acount, String password) {
        this.id = id;
        this.acount = acount;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAcount() {
        return acount;
    }

    public void setAcount(String acount) {
        this.acount = acount;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", acount=" + acount + ", password=" + password + '}';
    }
    
    
    
}
