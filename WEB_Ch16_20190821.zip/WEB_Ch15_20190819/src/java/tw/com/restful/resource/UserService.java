/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.restful.resource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.Connection;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import tw.com.bean.User;

@Path("user")
public class UserService {
    @Inject
    Logger log;
    @Inject
    Connection con;
    
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public String testResult(){
        return "Pass!";
    }
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson(){
        User user = new User(100,"test1","12345");
        ObjectMapper omp = new ObjectMapper();
        String json = "{empy:true}";
        try{
           json =  omp.writeValueAsString(user);   
        }catch(Exception ex){
            log.warning(ex.toString());
        }     
       return json;        
   }
}
