/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.cdi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class MyProduces {
      @Produces
      public Logger getLogger(InjectionPoint ip){  
          
          String className = ip.getMember().
                  getDeclaringClass().getName();             
          System.out.println("className:"+ className);
          return Logger.getLogger( className);
      }
      
      @Produces
      private Connection getDBConnection()throws SQLException,IOException{
      //G:\javaCode\WEB_Ch15_20190819\web\WEB-INF
          Properties p = new Properties();
          p.load(new FileInputStream("G:\\javaCode\\WEB_Ch15_20190819\\web\\WEB-INF\\db.properties"));
        String url = p.getProperty("url");
        String user = p.getProperty("user");
        String password = p.getProperty("password");        
          Connection conn = DriverManager.getConnection(url,user,password);    
          System.out.println("Connection");     
          return conn;
      }
      
      private void closeConnection(@Disposes Connection con)throws SQLException{
          con.close();
      }
      
}
