/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import tw.com.dao.UserDao;
import tw.com.data.DaoFactory;

/**
 *
 * @author howard
 */
@WebServlet(name = "UserServlet", urlPatterns = {"/UserServlet"})

/*
RestFul

GET 取資料
POST 新增資料
PUT 改資料


*/

public class UserServlet extends HttpServlet {
   @Inject
   private Connection conn; 
   @Inject
   private Logger log;
   private void createUser(String aconunt, String password,
           HttpServletResponse response,HttpSession session)throws IOException{
       // 建立帳號
       //1 先檢查帳號是否重複
       //2 如果沒重複 就建立帳號 成功 導入登入畫面
       //3 如果有重複 在跳回建立帳號
       
         UserDao userDao = DaoFactory.newUserDao(conn);     
         try{
             boolean isOnly = userDao.isOnlyAcount(aconunt);
             if (isOnly){
                 userDao.createUser(aconunt, password);
             }else{
                 session.setAttribute("Msg", "帳號重複!");                
                 response.sendRedirect("CreateUser.jsp");
             }
         }catch(SQLException ex){
             log.warning(ex.toString());
         }
         
//         if(true){
//             userDao.createUser(aconunt,password);
//         }else{
//             //xxxx
//         }       
        
   }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String aconunt = request.getParameter("acount");
        String password = request.getParameter("pwd");
//          String aconunt = "Test2";
//        String password = "12345";
        createUser(aconunt,password,response,request.getSession());      
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
