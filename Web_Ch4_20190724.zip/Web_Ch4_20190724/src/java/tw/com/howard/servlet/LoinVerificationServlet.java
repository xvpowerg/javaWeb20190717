/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
public class LoinVerificationServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)throws IOException{
        String defAccount = "qwer";
        String defPawd = "12345";     
        ArrayList<String> errorMsgList = new ArrayList<>();
         //設定request 使用UTF-8的編碼方式讀取
            //request.setCharacterEncoding("UTF-8");            
       //response 使用UTF-8的編碼方式輸出
           response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
         out.println("<html>");
          out.println("<head>");
           out.println(" <title>登入檢測</title>");
           out.println("<meta charset=\"UTF-8\">");
            out.println("</head>");
         out.println("<body>");
         String account = request.getParameter("account");
         String psw =  request.getParameter("psw");
        Optional<String>  accountOptional =  Optional.ofNullable(account);
        Optional<String>  pswOptional =  Optional.ofNullable(psw);
        
      
        
        accountOptional.ifPresent((in)->{
              if (in.trim().equals(defAccount)){
                  //System.out.println("帳號正確");
                  out.println("<h3>帳號正確</h3>");
              }else{
                  //System.out.println("帳號失敗");             
                  errorMsgList.add("帳號失敗");
              }        
        });
        String msg1 = accountOptional.orElseGet(()->"無效的登入方式");
        
           pswOptional.ifPresent((in)->{
              if (in.trim().equals(defPawd)){
                  //System.out.println("密碼正確");
                   out.println("<h3>密碼正確</h3>");
              }else{
                  errorMsgList.add("密碼失敗");                 
              }        
        });
          
         msg1 = pswOptional.orElseGet(()->"無效的登入方式");
        
         if (msg1.equals("無效的登入方式")){
             errorMsgList.add("無效的登入方式");   
         }
        
         if (!errorMsgList.isEmpty()){
               RequestDispatcher rd =  request.getRequestDispatcher("loing");
               request.setAttribute("msgList", errorMsgList);
                try {
                    rd.forward(request, response);
                } catch (ServletException ex) {
                    Logger.getLogger(LoinVerificationServlet.class.getName()).
                            log(Level.WARNING, null, ex);
                }
         }
  
        
           out.println("</body>");  
       out.println("</html>");
         
    }
}
