/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
public class MyLoingServlet extends  HttpServlet{    
    
    private void showMsg(List<String> msg,PrintWriter out){
         msg.forEach((str)->{
                  out.println("<div style=\"color:red;\">"+str+"</div>");              
           });
    }
     public void doGet(HttpServletRequest request,
                      HttpServletResponse response)throws IOException{
         //設定request 使用UTF-8的編碼方式讀取
            request.setCharacterEncoding("UTF-8");            
       //response 使用UTF-8的編碼方式輸出
           response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
           
       out.println("<html>");
          out.println("<head>");
           out.println(" <title>登入</title>");
           out.println("<meta charset=\"UTF-8\">");
            out.println("</head>");
         out.println("<body>");
         out.println("<form action=\"loing_verify\">\n" +
"            <input type=\"text\" name=\"account\" placeholder=\"帳號\">\n" +
"            <input type=\"password\" name=\"psw\" placeholder=\"密碼\">\n" +
"            <input type=\"submit\" value=\"確定\">  \n" +
"        </form>");
      
           List<String> msgList = (ArrayList)request.getAttribute("msgList");
             Optional<List<String>> listOpint = Optional.ofNullable(msgList);
             listOpint.ifPresent((list)->{
                 this.showMsg(list, out);             
             } );
             
//           if (msgList != null){
//              msgList.forEach((str)->{
//                  out.println("<div style=\"color:red;\">"+str+"</div>");              
//              });
//           }
         out.println("</body>");
         out.println("</html>");
         
         
//         out.println("<html>");
//         out.println("<body>");
//         out.println("<h1> Hello!!</h1>");
//        String account =  request.getParameter("account");
//        String psw =  request.getParameter("psw");
//          out.println("<h1> "+account+":"+psw+"</h1>");
//         out.println("</body>");
//         out.println("</html>");
     }
}



