package tw.com.servlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;

public class MyFirstServlet  extends HttpServlet{
    //如果網站使用網址方式進入會呼叫doGet
        public void doGet(HttpServletRequest req,
                HttpServletResponse resp)throws IOException{
           PrintWriter out =  resp.getWriter();
           out.print("<html>");           
               out.print("<body>");
                    out.print("<h1>MyFirstServlet</h1>");                    
               out.print("</body>");
           out.print("</html>");
        }
    //如果網站使用Form且method是Post方式進入會呼叫doPost
}
