/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import java.io.PrintWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.TreeMap;
import java.util.stream.Stream;
import java.io.IOException;
import java.time.LocalDateTime;
@WebServlet("/step2")
public class Step2Servlet1 extends HttpServlet {
    private static TreeMap <Integer,String> locationMap = new TreeMap<>();
    static{
        try{
          Path  path = Paths.get("c:","javadir","user_location.txt");
           Stream<String> stream = Files.lines(path);         
            stream.forEach((str)->{
                      String[]  lineData = str.split(" ");
                      int id = Integer.parseInt(lineData[0]);
                       String location = lineData[1];                
                      locationMap.put(id, location);
            });
         }catch(IOException ex){
            System.out.println(ex);
        }    
    }    
        
    public void todo(HttpServletRequest request,
            HttpServletResponse response) throws IOException{
        request.setCharacterEncoding("UTF-8");     
      String acount=  request.getParameter("acount");
      String pass = request.getParameter("pass1");
     System.out.println(acount+":"+pass);
     
           response.setContentType("text/html;charset=UTF-8");
           PrintWriter out = response.getWriter();
           out.println("<html>");
            out.println("<head>");  
             out.println("<meta charset=\"UTF-8\">");                
             out.println("</head>");            
             out.println("<body>");                 
         out.println("<form action=\"step3\" method=\"POST\">");
            out.println("<input type=\"text\" placeholder=\"請輸入姓名\" name=\"user_name\"/><br>");
            out.println("<input type=\"email\" placeholder=\"請輸入電子郵件\" name=\"user_email\" size=\"50\"/><br>");
              out.println("<select name=\"user_location\">");
              locationMap.forEach((k,v)->{
                  String optionStr = String.format("<option value='%d'>%s</option>", k,v);
                   out.println(optionStr);                  
              });
              
               out.println("</select>");
            out.println("  <input type=\"text\" placeholder=\"請輸入地址\" name=\"user_address\" size=\"100\"/><br>");        
              //<input type="hidden" name="v1" value=""/>
              
          out.println(String.format("<input type=\"hidden\" name=\"acount\" value='%s'/>", acount)); 
          out.println(String.format("<input type=\"hidden\" name=\"pass\" value='%s'/>", pass)); 
          out.println(String.format("<input type=\"hidden\" name=\"setp2_time\" value='%s'/>",
                                LocalDateTime.now().toString()));  
            
       out.println("<input type=\"submit\" value=\"下一步\">");
       out.println("</form>");
           out.println("</body>");                      
           out.println("</html>"); 
    }
    
    
    public void doPost(HttpServletRequest request,
            HttpServletResponse response)throws IOException{
        todo(request,response);
    }
    
    public void doGet(HttpServletRequest request,
            HttpServletResponse response) 
            throws IOException{
           todo(request,response);     
    }
}
