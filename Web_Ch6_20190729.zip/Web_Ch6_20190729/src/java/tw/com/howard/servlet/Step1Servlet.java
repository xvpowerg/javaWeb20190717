/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/step1")
public class Step1Servlet extends HttpServlet {
    
    
    
    public void doGet(HttpServletRequest request,
            HttpServletResponse response) 
            throws IOException{
           request.setCharacterEncoding("UTF-8");                
           response.setContentType("text/html;charset=UTF-8");

           PrintWriter out = response.getWriter();
           out.println("<html>");
            out.println("<head>");  
             out.println("<meta charset=\"UTF-8\">");                
             out.println("</head>");            
             out.println("<body>");

         out.println("<form action=\"step2\" method=\"post\">");
            out.println(" <input type=\"text\" placeholder=\"請輸入帳號\" name=\"acount\"/><br>");
            out.println("<input type=\"password\" placeholder=\"請輸入密碼\" name=\"pass1\"/><br>");
            out.println(" <input type=\"password\" placeholder=\"請輸入複查密碼\" name=\"pass2\"/><br>");        
       out.println("<input type=\"submit\" value=\"下一步\">");
       out.println("</form>");
           out.println("</body>");                      
           out.println("</html>");         
    }
}
