/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

/**
 *
 * @author howard
 */
public class TestObj {
    
    private int value = 10;
    public static void main(String[] args){
        TestObj t1= new TestObj();
         TestObj t2= new TestObj();
         t1.value = 92;
         t2.value = 83;
         System.out.println(t1.value);
         System.out.println(t2.value);
    }
}
