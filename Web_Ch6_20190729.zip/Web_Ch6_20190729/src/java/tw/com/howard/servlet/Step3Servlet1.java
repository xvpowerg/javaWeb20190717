/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/step3")
public class Step3Servlet1 extends HttpServlet {
    
    
     public void doPost(HttpServletRequest request,
            HttpServletResponse response)throws IOException{
        todo(request,response);
    }
     
     public void todo(HttpServletRequest request,
            HttpServletResponse response) throws IOException{
           request.setCharacterEncoding("UTF-8");                
           response.setContentType("text/html;charset=UTF-8");
           String acount =  request.getParameter("acount");
           String pass =  request.getParameter("pass");
           String setp2Time =  request.getParameter("setp2_time");
           
           PrintWriter out = response.getWriter();
           out.println("<html>");
            out.println("<head>");  
             out.println("<meta charset=\"UTF-8\">");                
             out.println("</head>");            
             out.println("<body>");
                  out.println("<h1>帳號:"+acount+" </h1>");
                  out.println("<h1>密碼:"+pass+" </h1>");
                  out.println("<h1>setp2Time:"+setp2Time+" </h1>");
//         out.println("<form action=\"step2\" method=\"post\">");
//            out.println(" <input type=\"text\" placeholder=\"請輸入帳號\" name=\"acount\"/><br>");
//            out.println("<input type=\"password\" placeholder=\"請輸入密碼\" name=\"pass1\"/><br>");
//            out.println(" <input type=\"password\" placeholder=\"請輸入複查密碼\" name=\"pass2\"/><br>");        
//       out.println("<input type=\"submit\" value=\"下一步\">");
//       out.println("</form>");
           out.println("</body>");                      
           out.println("</html>"); 
         
         
     }
    
    public void doGet(HttpServletRequest request,
            HttpServletResponse response) 
            throws IOException{
         
    }
}
