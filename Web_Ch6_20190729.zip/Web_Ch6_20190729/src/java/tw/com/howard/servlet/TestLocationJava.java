/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;
import java.util.TreeMap;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class TestLocationJava {
    
    public static void main(String[] args) throws IOException{
        Path  path = Paths.get("c:","javadir","user_location.txt");
        Stream<String> stream = Files.lines(path);
       
//        TreeMap<Integer,String> treeMap2= stream.collect(Collectors.toMap((str)->{
//                    String[]  key= str.split(" ");
//                    return Integer.parseInt(key[0]);
//                    }, 
//                (str)->{
//                    String[]  value= str.split(" ");
//                    return value[1];
//                }, 
//                (ov,nv)->{return ov;}, 
//                TreeMap::new));
        
         TreeMap<Integer,String> treeMap = new TreeMap<>();
        stream.forEach((str)->{
                  String[]  lineData = str.split(" ");
                  int id = Integer.parseInt(lineData[0]);
                   String location = lineData[1];                
                  treeMap.put(id, location);
        });
        System.out.println(treeMap);
    }
}
