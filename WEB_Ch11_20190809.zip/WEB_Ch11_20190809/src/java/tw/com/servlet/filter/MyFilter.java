/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.servlet.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author howard
 */
@WebFilter(urlPatterns = {"/OderServelt"})
public class MyFilter implements Filter {
    public void init(FilterConfig filterConfig){
        System.out.println("MyFilter init");
    }
    
    public void doFilter(ServletRequest request,
            ServletResponse response,FilterChain chain)throws 
                                        IOException,ServletException{
         System.out.println("MyFilter doFilter 1");
         HttpServletRequest httpRequest = (HttpServletRequest)request;
        HttpSession  session = (HttpSession)httpRequest.getSession();
        String name =  httpRequest.getServletPath();
        if (!name.equals("UserLoginServelt")){
            session.getAttribute("pass");
        }else{
            httpRequest.getRequestDispatcher("/MyJsp.jsp").forward(request, response);
        }
          System.out.println("MyFilter doFilter name:"+name);
         chain.doFilter(request, response);
         String msg = (String)request.getAttribute("orderMsg");
        System.out.println("MyFilter doFilter 2:"+msg);
    }
    
    public void destroy(){
        System.out.println("MyFilter destroy");
    }
}
