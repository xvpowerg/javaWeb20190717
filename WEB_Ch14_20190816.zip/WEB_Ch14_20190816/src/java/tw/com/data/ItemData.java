/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.data;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import tw.com.bean.Item;

/**
 *
 * @author howard
 */
public class ItemData {
    private static List<Item> items = new ArrayList<>();
    public static void add(Item item){
        items.add(item);
    }
    
    public static void foreach(Consumer<Item> com){
        items.forEach(com);
    }
    
    public static List<Item> getItems(){
        return items;
    }
    
}
