/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.cdi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Named;
import tw.com.annnotation.Animal;
import tw.com.annnotation.Fruit;
import tw.com.bean.Book;
import tw.com.servlet.TestEventServlet;

public class MyProduces {
   private static final String  EVENServlet;
   static{
       EVENServlet = "";
   }
    @Fruit
    @Produces 
    public List<String> getFruit(){
        List<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Charry");
        fruits.add("Kewi");
        return fruits;
    }
    
    
    
     @Animal
     @Produces
    public List<String> getAnimal(){
         List<String> animal = new ArrayList<>();
         animal.add("Dog");
         animal.add("Cat");
         animal.add("Bear");
         animal.add("Tiger");
         return animal;
    }
      @Produces
      public Map<String,Integer> getMap(){
          Map<String,Integer> map = new HashMap<>();
          map.put("Ken", 70);
          map.put("Vivin", 83);
          map.put("Lindy", 82);
          return map;
      }
       @Produces 
       @Named("defaultBook")
      public Book getDefaultBook(){
          Random ran = new Random();
          return new Book(ran.nextInt(100000),
                    "未填寫");
      }
      @Produces
      public Logger getLogger(InjectionPoint ip){  
          
          String className = ip.getMember().
                  getDeclaringClass().getName();
        
     
          System.out.println("className:"+ className);
          return Logger.getLogger( className);
      }
      
      
}
