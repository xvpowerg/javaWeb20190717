/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.cdi;

import java.util.logging.Logger;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import tw.com.bean.Item;
import tw.com.data.ItemData;

public class ItemEventHandler {
@Inject
Logger logger;
    public void addItem(@Observes Item item){
        ItemData.add(item);
        logger.info("addItem Event:"+item);
    }
}
