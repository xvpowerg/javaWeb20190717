/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class MyServletContextListener implements ServletContextListener {
    public static final String ONLINE_COUNT="onlineCount";
    public void contextDestroyed(ServletContextEvent sce){
       System.out.println("MyServletContextListener contextDestroyed");
    }
    public void contextInitialized(ServletContextEvent sce){
          System.out.println("MyServletContextListener contextInitialized");
          sce.getServletContext().setAttribute(ONLINE_COUNT, 0);       
    }

}
