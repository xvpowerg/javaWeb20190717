/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.listener;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class LoginSessionListener implements HttpSessionListener{

    @Override
    public void sessionCreated(HttpSessionEvent se) {
      ServletContext servletContext = 
              se.getSession().getServletContext();
    int onlineCount=
        (Integer)servletContext.getAttribute(
                MyServletContextListener.ONLINE_COUNT);
    servletContext.setAttribute(MyServletContextListener.ONLINE_COUNT,
            ++onlineCount);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        System.out.println("LoginSessionListener sessionDestroyed!");
        ServletContext servletContext = 
              se.getSession().getServletContext();
  int onlineCount=
        (Integer)servletContext.getAttribute(
                MyServletContextListener.ONLINE_COUNT);
    servletContext.setAttribute(MyServletContextListener.ONLINE_COUNT,
            --onlineCount);
    }
    
}
