/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.bean;

import javax.enterprise.inject.Alternative;

@Alternative
public class MyNumberGenerator implements NumberGenerator{
    public  String getNumber(){
        return "MyNumberGenerator";
    }
}
