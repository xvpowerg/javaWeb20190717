/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.bean;

import javax.inject.Named;

/**
 *
 * @author howard
 */
@Named("airplan")
public class AirPlan implements Fly {
    public void flying(){
        System.out.println("飛機飛飛!!");
    }
}
