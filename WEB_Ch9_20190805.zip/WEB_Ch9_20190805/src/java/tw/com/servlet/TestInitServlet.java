/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;
/**
 *
 * @author howard
 */
@WebServlet(name = "TestInitServlet", urlPatterns = {"/TestInitServlet"},loadOnStartup = 1)
public class TestInitServlet extends HttpServlet {
    private HashMap<String,String> mapNumberToSring = new HashMap();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
          String key = request.getParameter("key");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TestInitServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet TestInitServlet at " + mapNumberToSring.get(key) + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

      public void init(){   
            System.out.println("TestInitServlet1...");
          Random ran = new Random();
          System.out.println("開始計算~~~");
          try{
              TimeUnit.SECONDS.sleep(5);
          } catch (InterruptedException ex) {
              System.out.println(ex);
        }          
          for (int i =1;i<=1000;i++){
              StringBuffer sb = new StringBuffer();
              for (int k =1;k<=5;k++){
                  char upChar = (char) (ran.nextInt(26)+'A');
                  char lowChar = (char) (ran.nextInt(26)+'a');
                  sb.append(upChar);
                  sb.append(lowChar);                  
              }               
              mapNumberToSring.put(i+"", sb.toString());              
          }
        System.out.println("完成計算~~~");  
     }
    
}
