/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.filter;

import java.io.IOException;
import java.util.HashSet;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/*")
public class CheckUserLoginFilter implements Filter {
    private static HashSet<String> specialUrlSet = new HashSet<>();
    private static String[] specialfilterArray = {"/UserLogin.html",
    "/UserLoginServlet"};
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {          
        for (String url :  specialfilterArray){
            specialUrlSet.add(url.toLowerCase());
        }                
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {       
       HttpServletRequest httpReq = (HttpServletRequest)request;
       HttpServletResponse httpRespon = (HttpServletResponse)response;
        HttpSession session =   httpReq.getSession();
        
        Object acount =  session.getAttribute("acount");
       
       // System.out.println("CheckUserLoginFilter 1");
         String path1 =  httpReq.getServletPath();
      //   System.out.println("path1:"+path1);
   
        
         //除了UserLogin之外的頁面處理         
         if (path1.equalsIgnoreCase("/UserLogin.html") ||
             path1.equalsIgnoreCase("/UserLoginServlet")){
             if (acount!= null){
                httpRespon.sendRedirect("Page1Servlet");  
             }             
         }else if(acount== null){             
               httpRespon.sendRedirect("UserLogin.html");             
         }       
         chain.doFilter(request, response);  
       // System.out.println("CheckUserLoginFilter 2");
        
        /*//使用HashSet
                 if (specialUrlSet .contains(path1.toLowerCase())){
             if (acount!= null){
                httpRespon.sendRedirect("Page1Servlet");  
             }             
         }else if(acount== null){             
               httpRespon.sendRedirect("UserLogin.html");             
         }    
        */
        
    }

    @Override
    public void destroy() {       
    }
    
}
