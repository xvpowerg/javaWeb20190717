/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.listener;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.annotation.WebListener;

/**
 *
 * @author howard
 */

@WebListener
public class MyRequestAttrListener implements ServletRequestAttributeListener{
      public void attributeAdded(ServletRequestAttributeEvent seae){
         
          System.out.println("attributeAdded name:"+
                  seae.getName()+" value:"+seae.getValue());
      }
      public void attributeRemoved(ServletRequestAttributeEvent seae){
          System.out.println("attributeRemoved name:"+
                  seae.getName()+" value:"+seae.getValue());
      }
      
       public void attributeReplaced(ServletRequestAttributeEvent seae){
          System.out.println("attributeReplaced name:"+
                  seae.getName()+" value:"+seae.getValue());
      }

}
