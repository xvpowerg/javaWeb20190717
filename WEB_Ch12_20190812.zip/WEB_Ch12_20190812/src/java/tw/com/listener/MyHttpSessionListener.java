/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


public class MyHttpSessionListener implements HttpSessionListener {
    public void sessionCreated(HttpSessionEvent se){
        System.out.println("sessionCreated ");           
    }
    public void sessionDestroyed(HttpSessionEvent se){
        System.out.println("sessionDestroyed ");
    }
}
