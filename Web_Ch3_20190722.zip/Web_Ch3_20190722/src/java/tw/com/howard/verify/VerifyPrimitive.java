/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.verify;

import java.util.logging.Level;
import java.util.logging.Logger;
import tw.com.howard.servlet.LoingServlet;

/**
 *
 * @author howard
 */
public class VerifyPrimitive {
       public static int checkIntParameter(String parar,String msg){
                int pararInt = -1;
               if (parar != null && !parar.trim().isEmpty()){
                 try{
                     pararInt =  Integer.parseInt(parar);   
                 }catch(NumberFormatException ex){                   
                     Logger.getLogger(LoingServlet.class.getName()).
                             log(Level.WARNING, msg);
                 }                 
             }
             return pararInt;
    }
}
