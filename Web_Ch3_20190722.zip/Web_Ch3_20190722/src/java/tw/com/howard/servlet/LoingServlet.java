/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Random;
import static  tw.com.howard.verify.VerifyPrimitive.checkIntParameter;
public class LoingServlet extends HttpServlet {
    private static Random ran = new  Random();
    
    private void printTable(PrintWriter out,int size){
        out.println("<table>");
        for (int i =1;i<=size;i++){
            
            String trString =  String.format("<tr%s>", 
                    i %2 ==0? " style=\"background-color:#dddddd;\"":"");
            out.println(trString);
              out.println("<td>");
                 out.println(ran.nextInt(10000));   
              out.println("</td>");              
              out.println("<td>");
                  out.println(ran.nextInt(10000));   
              out.println("</td>");
            out.println("</tr>");
        }
        out.println("</table>");
    }
    
 
     public void doGet(HttpServletRequest rq,
             HttpServletResponse resp) throws IOException{
             //所有的Parameter都是字串
           
        
             String page =  rq.getParameter("page");   
             String size = rq.getParameter("size");
             
              //使用物件管理驗證程式碼 
           /*  int sizeInt = checkIntParameter(size,"錯誤的size");             
              int pageInt = checkIntParameter(page,"錯誤的page");*/
         
               int pageInt = -1;
               int sizeInt = -1;
               //注意這邊size可能出錯
               sizeInt = Integer.parseInt(size);
               if (page != null && !page.trim().isEmpty()){
                 try{
                     pageInt =  Integer.parseInt(page);   
                 }catch(NumberFormatException ex){                   
                     Logger.getLogger(LoingServlet.class.getName()).
                             log(Level.WARNING, "錯誤的page");
                 }  
               }
               
           PrintWriter out =  resp.getWriter();
          out.println("<html>");
            out.println("<h1>");
              out.println("Hello!!"+"page:"+pageInt+"size:"+size);
              printTable(out,sizeInt);
            out.println("</h1>");          
          out.println("</html>");
     }
}
