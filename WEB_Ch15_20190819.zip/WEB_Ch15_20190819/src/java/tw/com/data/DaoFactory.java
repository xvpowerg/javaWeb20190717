/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.data;

import tw.com.dao.UserDao;
import tw.com.sql.derby.UserDaoDeabry;
import tw.com.sql.oracle.UserDaoOracle;

/**
 *
 * @author howard
 */
public class DaoFactory {
    static int type = 2;
    public static UserDao newUserDao(){
        switch(type){
            case 1:
           return new UserDaoDeabry();
            case 2:
           return new UserDaoOracle();
        }
        return null;
    }
}
