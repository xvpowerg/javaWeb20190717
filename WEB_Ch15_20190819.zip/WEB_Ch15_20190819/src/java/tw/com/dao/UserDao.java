/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.dao;

import tw.com.bean.User;

/**
 *
 * @author howard
 */
public interface UserDao {
    //CRUD
    //C 建立Create
    //R 讀 Read
    //U Update
    //D Delete
    public boolean createUser(String acount,String password);
    public User readUser(String acount,String password);
    
    
}
