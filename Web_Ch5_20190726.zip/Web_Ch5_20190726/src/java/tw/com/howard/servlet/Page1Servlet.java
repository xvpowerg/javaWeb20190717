/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Set;
import javax.servlet.annotation.WebServlet;
/**
 *
 * @author howard
 */

//@WebServlet({"/page1","/creatPage1"}) //有/page1跟creatPage1 同時對應到Page1Servlet
//@WebServlet("/page1")//只有/page1同時對應到Page1Servlet
@WebServlet(name="Page1Servlet",urlPatterns = {"/page1"})//如果WebServelet name與WEB.xml的一樣
//會使用web.xml作為設定值
public class Page1Servlet extends HttpServlet {   
    private void showHtmlPage(HttpServletRequest request,
            HttpServletResponse response)throws IOException{
         //設定request 使用UTF-8的編碼方式讀取
           request.setCharacterEncoding("UTF-8");            
       //response 使用UTF-8的編碼方式輸出
           response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
          out.print("<html>");
           out.println("<head>");
           out.println(" <title>Page1</title>");
           out.println("<meta charset=\"UTF-8\">");
            out.println("</head>");          
            out.println("<body>");
            
         out.print(" <form action=\"page2\" method=\"GET\">"); 
             out.println("<div>");
            Set checkdSet = (Set)request.getAttribute("checkdSet");
             for (int i = 1;i< Page2Servlet.HOBBYS.length;i++){
                 
                 String checkedTag = checkdSet != null && checkdSet.contains(i)?"checked":"";
                   out.print(Page2Servlet.HOBBYS[i]+"<input type=\"checkbox\" name=\"hobby\" value=\""+ i +"\""+checkedTag+" />"); 
             }
//             out.print("閱讀<input type=\"checkbox\" name=\"hobby\" value=\"1\"/>"); 
//             out.print("運動<input type=\"checkbox\" name=\"hobby\" value=\"2\"/>"); 
//             out.print(" 音樂<input type=\"checkbox\" name=\"hobby\" value=\"3\"/>");    
                out.println("</div>");
                out.println("<input type=\"submit\" value=\"送出\">");
                out.println("</form>");    
                
                out.println("<h2>");
                 String errorMsg = (String)request.getAttribute("errorMsg");
                out.println(errorMsg != null?errorMsg:"" ) ;
                out.println("</h2>");
      
            
//            out.println("<h1>"+request.getServletPath()+"<h1>");      
//             String hobby = request.getParameter("hobby");
//             out.println("<h1>"+hobby+"</h1>");      
//           String[] hobbys = request.getParameterValues("hobby");
//           for (String value : hobbys){
//                       out.println("<h1>"+value+"</h1>");       
//           }
             out.println("</body>");
          out.print("</html>");
        
        
    }
    
    public void doGet(HttpServletRequest request,HttpServletResponse response)
                throws IOException{
        showHtmlPage(request,response);
    }
   public void doPost(HttpServletRequest request,HttpServletResponse response){
        
    }
    
}
