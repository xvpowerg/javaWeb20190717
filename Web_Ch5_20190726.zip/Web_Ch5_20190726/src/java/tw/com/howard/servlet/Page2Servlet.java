/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.howard.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Optional;
import javax.servlet.ServletException;
/**
 *
 * @author howard
 */
@WebServlet("/page2")
public class Page2Servlet  extends HttpServlet{
    
   public final static String[] HOBBYS={"","閱讀","運動","音樂"};
 private void showHtmlPage(HttpServletRequest request,
            HttpServletResponse response,String[] hobbys )throws IOException{
       //設定request 使用UTF-8的編碼方式讀取
           request.setCharacterEncoding("UTF-8");            
       //response 使用UTF-8的編碼方式輸出
           response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
          out.print("<html>");
           out.println("<head>");
           out.println(" <title>Page1</title>");
           out.println("<meta charset=\"UTF-8\">");
            out.println("</head>");          
            out.println("<body>");  
            for(String v : hobbys){
                out.println("<h3>");  
                out.println(HOBBYS[Integer.parseInt(v)]);  
                out.println("</h3>");  
            }
            out.println("</body>");
            out.print("</html>");     
            
 }   
 private void  verifyCheckBox(Optional<String[]> checkValues){
        String[] values = 
                checkValues.orElseThrow(()->new IllegalArgumentException("沒有勾選嗜好"));
        if (values.length < 2){
           throw new IllegalArgumentException("勾選數量不正確");
        }
        
 }
     
    public void doGet(HttpServletRequest request,HttpServletResponse response)
                throws IOException,ServletException{
        String[] hobbys = request.getParameterValues("hobby");
        Optional<String[]>  hobbysOptional = Optional.ofNullable(hobbys);
        HashSet<Integer> checkdSet = new HashSet<>();
        try{
             verifyCheckBox(hobbysOptional);        
             showHtmlPage(request,response,hobbys);  
        }catch(IllegalArgumentException ex){
             String errorMsg =  ex.getMessage();
             System.out.println(errorMsg);
             request.setAttribute("errorMsg", errorMsg);
             hobbysOptional.ifPresent( (strArray)->{
                for (String v : strArray){
                    checkdSet.add(Integer.parseInt(v));
                }           
             }  );
             
              request.setAttribute("checkdSet", checkdSet);
             request.getRequestDispatcher("/myPage1").forward(request, response);
             PrintWriter out = response.getWriter();
             response.setContentType("text/html;charset=UTF-8");
             out.print("<html>");
                out.print("<body>");
                out.print("<h1>Test!!</h1>");                
                out.print("</body>");
                out.print("</html>");
                out.flush();
            
        }
       
        
    }
   public void doPost(HttpServletRequest request,HttpServletResponse response){
        
    }
 
}
